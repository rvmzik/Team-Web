from django.urls import path
from .views import *
from django.urls import path
urlpatterns = {
    path('', views.home, name='home'),
    path('News/', views.News, name='News' )
}

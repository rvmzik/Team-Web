from django.http.response import HttpResponse
from django.shortcuts import render

from .import views


def home(request) :
    return render(request, 'testapp/home.html')


def News(request) :
    return render(request, 'testapp/News.html')

    
